// Definicion de Variables y constantes y llamada de librerias

const express = require('express');
const app = express ();
const port = 4001
const path = require('path');
const render = require('ejs');
const bodyParser = require ('body-parser');
const bcrypt = require('bcrypt');
const { Client } = require('pg');
const { Router } = require('express');
const cors = require('cors');

require('dotenv').config();





app.use(cors());


// Definicion de Rutas para levantar los HTML

// set the view engine to ejs
app.set('view engine', 'ejs');

// Base middlewares
app.use('/', express.static(path.join(__dirname, 'public')));
app.use(express.json());
app.use(express.urlencoded({
  extended: true
}));




app.post('/contacto', async function(req,res){

    res.send({success: true})
})


//  USUARIOS //
const users = [];

app.get('/users', function(req,res){

    res.send(users)});

    app.post ('/registracion', async function(req,res){

        const id = users.length + 1;
        const nombre = req.body.nombre;
        const apellido = req.body.apellido;
        const email = req.body.email;
        const celular = req.body.celular;
        const contraseña = req.body.contraseña;
        
        

        const nuevoUsuario = {
            "id" : id,
            "nombre": nombre,
            "apellido": apellido,
            "email": email,
            "celular": celular,
            "contraseña": await bcrypt.hash(req.body.contraseña,12),
            
        };



        
               users.push (nuevoUsuario);
               console.log(users)
               
               res.send({success: true})
    })

// LOG IN//



app.get('/productos1',function(req,res){

    const Productos = [
        {
          id: 1,
          nombre: "Lulu",
          precio: 1150,
          categoria: "Buzos",
          temporada: "Invierno",
          imagen: "/assets/Imagen3.jpeg"
          
        },
        {
            id: 2,
            nombre: "Mare",
            precio: 1300,
            categoria: "Chaquetas",
            temporada: "Invierno",
            imagen: "/assets/Imagen4.jpeg"       
          },
          {
            id: 3,
            nombre: "Akira",
            precio: 1150,
            categoria: "Chalecos",
            temporada: "Invierno",
            imagen: "/assets/Imagen5.jpeg"
            
          },
          {
            id: 4,
            nombre: "Bombay",
            precio: 2000,
            categoria: "Chaquetas",
            temporada: "Invierno",
            imagen: "/assets/Imagen6.jpeg"
          },
          {
            id: 5,
            nombre: "Lulu2",
            precio: 1200,
            categoria: "Buzos",
            temporada: "Invierno",
            imagen: "/assets/Imagen7.jpeg"
            
          },
          {
            id: 6,
            nombre: "Bono",
            precio: 1150,
            categoria: "Pantalones",
            temporada: "Invierno",
            imagen: "/assets/Imagen8.jpeg"
            
          },
          {
            id: 7,
            nombre: "Teresa",
            precio: 1150,
            categoria: "Shorts",
            temporada: "Verano",
            imagen: "/assets/Imagen9.jpeg"
            
          },
          {
            id: 8,
            nombre: "Coco",
            precio: 1300,
            categoria: "Mono",
            temporada: "Verano",
            imagen: "/assets/Imagen11.jpeg"
            
          },
          {
            id: 9,
            nombre: "Cristina",
            precio: 1300,
            categoria: "Camisas",
            temporada: "Verano",
            imagen: "/assets/mochila.jpeg"
          },
          {
            id: 10,
            nombre: "Collar",
            precio: 1300,
            categoria: "Accesorios",
            temporada: "Invierno",
            imagen: "/assets/mochila2.jpeg"
          },
      ];
      

    res.send(Productos);
})
   
app.use('/productos',productosRouter);

app.get('/login', function(req,res){

    res.send(success = true) ;


});
    app.post('/login',  async function(req,res){
      
     
     const email = req.body.email;
     const contraseña = req.body.contraseña;     
     let usuarioObj = null;
     let resultado = false;
     
     
            
        users.forEach(function(usr){
            if(usr.email === email){ 
                usuarioObj = usr; 
            }

      });

         
    if(usuarioObj !== null) {
        
        resultado = await bcrypt.compare(contraseña,usuarioObj.contraseña);
    }

   
    if(resultado){
        res.redirect('/');
        return;
    } else { 
        res.render('inciarsesion');
    }
    
    console.log(resultado)
   
});






  

// LISTEN TO PORT
app.listen(port);






