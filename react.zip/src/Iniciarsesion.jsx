import React from "react";
import { Fragment } from 'react';
import "./Iniciarsesion.css"

const Iniciarsesion = () => { 

return(

    <Fragment>
    
 <form>

<div className="registracion12">

<div className="infopersonal13">
                <h2>Inicia sesión!</h2>
            </div>

<div className="mb-3">
    <label for="exampleInputEmail1" className="form-label" name="email" id="email">Email</label>
    <input type="email" className="form-control" name="email" placeholder="Escribe tu email" data-validate="{required:true}" autocomplete="on" id="email"/>
    
  </div>
  <div className="mb-3">
    <label for="exampleInputPassword1" className="form-label" >Password</label>
    <input type="password" className="form-control" name="contraseña" placeholder="Escribe tu contraseña" data-validate="{required:true}"autocomplete="off" id="contraseña"/>
  </div>
 
  <button type="submit" className="btn btn-secondary">Iniciar sesión</button>
  <div className="redireccion">
            <label> <a className="red12" href="/registracion">No tienes cuenta? Regístrate!</a> </label>
        </div>
    
     
    

</div>
</form>

    </Fragment>
)

}
export default Iniciarsesion   



