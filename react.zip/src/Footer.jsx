
import React from 'react';
import './Footer.css';


const Footer = () => {

 return(  

  
<footer>

    <div className="piedepagina">


      <div className="newsletter">
        <div>
          <h1 className="news">NEWSLETTER</h1>
        </div>
        <div>
          <h2 className="novedades">RECIBE TODAS NUESTRAS NOVEDADES!</h2>
        </div>
        <form method="POST" action="/" id="suscribe">
          <input name="newsletter1" type="email" id="newsletter1" placeholder="Ingresa tu e-mail" />
          <span>
            <button type="submit" className="sucribirse">SUSCRIBIRSE</button>
          </span>
        </form>
      </div>

      <div className="titulomediosdepago">
        <div className="mediosdepago">
          <span><i className="fab fa-cc-visa" style={{color: "#ffffff"}} width="6" height="6"></i></span>
          <span><i className="fab fa-cc-mastercard" style={{color: "#ffffff"}} width="6" height="6"></i></span>
          <span><i className="fab fa-cc-paypal" style={{color: "#ffffff"}} width="15" height="15"></i></span>
          <span><i className="fab fa-cc-amex" style={{color: "#ffffff"}} width="6" height="6"></i></span>
          <span><i className="fab fa-amazon-pay" style={{color: "#ffffff"}} width="6" height="6"></i></span>
        </div>
      </div>



      <div className="redessociales">

        <span className="redessocialestexto"> SOCIAL MEDIA</span>

        <span className="instagram">
          <a href="https://www.instagram.com/sietemares.uy/" target="_blank"><i className="fab fa-instagram"></i></a>
        </span>



        <div className="copy"> © Copyright 2021 / Guillermo Vázquez Gelsi </div>


      </div>
    </div>

    </footer>
  
 )


}

  export default Footer;