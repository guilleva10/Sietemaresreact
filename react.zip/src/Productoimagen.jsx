import React from "react";
import "./Productoimagen.css";

const Item = ({ id, nombre, categoria, temporada, precio, imagen },{talle1,talle2,talle3,talle4}) => {
  const formattedPrice = `$ ${precio} `;

  return (
    <span className="articulos">
      <span className="itemproducto">
        <img className="imagen" width="200vw" height="250vh" src={imagen} />

        <div classname="especificaciones">
        <span className="talle">
            <h6>  Talles Disponibles</h6>
            <br />
              <a> XS </a>
              <a> S </a>
              <a> M </a>
              <a> L </a>
              <i class="far fa-heart"></i>
              
            </span>
          <span>
            <h2 classname="productonombre">
              {nombre} - {categoria}
            </h2>

            <h3 classname="productoprecio">{formattedPrice}</h3>
          </span>

          <span>
            <span>
              <button className="añadir">Añadir al carrito</button>
            </span>

            
          </span>
        </div>
      </span>
    </span>
  );
};

export default Item;
