

export const Talles = [
    {
      id: 1,
      Nombre:"talle1",
      Talle: "XS",
      
      
    },
    {
      id: 2,
      Nombre:"talle2",
      Talle: "S",
      
      
    },
    {
      id: 3,
      Nombre:"talle3",
      Talle: "M",
      
      
    },
    {
      id: 4,
      Nombre:"talle4",
      Talle: "L",
      
      
    },
    {
      id: 5,
      Nombre:"talle5",
      Talle: "XL",
      
      
    },  

  ];
  