import React, { Fragment } from 'react';
import './Main.css';
import { 
  BrowserRouter as Router,
  Switch,
  Route,
} from "react-router-dom";
import Registracion from './Registracion';
import Iniciarsesion from './Iniciarsesion';
import Aboutus from './Aboutus';
import Homecontent from './Homecontent';
import Contacto from './Contacto';
import Store from './Store';

const Main = () => {

 return(  

 
<main> 
<Fragment>
  <Router>
<Switch>
      <Route exact path="/">
              <Homecontent />
            </Route>
      <Route exact path="/login">
              <Iniciarsesion />
      </Route>
      <Route exact path="/registracion">
              <Registracion />
      </Route>
      
      <Route  path="/aboutus">
              <Aboutus />
      </Route>
      <Route exact path="/contacto">
              <Contacto />
      </Route>

      <Route exact path="/store">
              <Store />
      </Route>
    </Switch>
    </Router>
    </Fragment>
</main>

 )


}

  export default Main;