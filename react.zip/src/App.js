import React, { useState } from "react";
import Nav from "./Nav.js";
import "./apptotal.css";
import Homecontent from "./Homecontent.jsx";
import Footer from "./Footer.jsx";
import Iconos from "./Iconos.jsx";
import { Fragment } from "react";
import Iniciarsesion from "./Iniciarsesion.jsx";
import Main from "./Main.jsx";
import Store from "./Store.jsx";
import Registracion from "./Registracion.jsx";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import Aboutus from "./Aboutus.jsx";
import Contacto from "./Contacto.jsx";
import { render } from "react-dom";

function App() {


  return (
    <Fragment>
      <Nav />
      <Main />

      <Iconos />

      <Footer />
    </Fragment>
  );
}

export default App;
