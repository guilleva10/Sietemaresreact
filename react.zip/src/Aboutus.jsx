import React from "react";
import { Fragment } from "react";
import "./Aboutus.css";
import Hometitulo from "./Hometitulo.jsx";

const Aboutus = () => {
  return (
    <Fragment>
      <div className="quienessomos">
        <Hometitulo nombre="Who we are?"></Hometitulo>
      </div>
      <div className="aboutus">
        <p>
          <strong>Siete Mares</strong> es una empresa familiar que nace en 2021,
          abriendo sus puertas por primera vez en el departamento de Montevideo
          mediante la modalidad on-line.
        </p>
        <p>
          <br />
          Somos una empresa joven, que nos apasiona la moda. Es por eso, que
          para nosotros satisfacer las necesidades del cliente es nuestra
          principal prioridad.
        </p>
        <p>
          <br />
          Siete Mares va dirigido a todas las mujeres, sin importar la edad.
          Buscamos una línea básica de productos sin perder de vista la moda y
          su tendencia. En nuestras tiendas encontrarán una amplia gama de
          productos de calidad a precios muy accesibles.
        </p>
        <p>
          <br />
          Nuestro objetivo es mejorar día a día, para poder ofrecerle al cliente
          exactamente lo que está buscando, ese es nuestro mayor desafío y nos
          sentimos orgullosos de trabajar constantemente para lograrlo.
        </p>
        <span className="instagram1">
          <a href="https://www.instagram.com/sietemares.uy/" target="_blank">
            <i className="fab fa-instagram"></i>
          </a>{" "}
          /sietemares.uy/
        </span>
      </div>
    </Fragment>
  );
};

export default Aboutus;
