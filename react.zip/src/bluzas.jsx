
import react from 'react';
import Item  from './Productoimagen';

const Bluzas = () => {
    return(
        <div>
<Item
id="1" 
nombre ="Lulu"
precio = {15}
imagen = "C:\Users\Guillermo\Desktop\proyectoreact\sietemares\src\assets\Mochila.jpeg">

</Item>

<Item
id="2" 
nombre ="Akira"
precio = {25}
imagen= "./sietemares\src\assets\Imagenes\fondo.jpeg">
</Item>

 <Item
 id="3" 
 nombre ="Lulu2"
 precio = {125}
 imagen = "./sietemares\src\assets\Imagenes\fondo.jpeg">
 </Item>
  <Item
  id="4" 
  nombre ="producto4"
  precio = {15}
  imagen = "./sietemares\src\assets\Imagenes\fondo.jpeg">
  </Item>
  </div>
    )
}
export default Bluzas