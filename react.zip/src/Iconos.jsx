import React from 'react';
import { Fragment } from 'react';
import './Iconos.css';
 
const subir =() => {


  document.documentElement.scrollTop = [0];
};






const Iconos = () => {

    return(

        <Fragment>
    <span id="up"onClick={() => subir()}>
    <i className="fas fa-arrow-alt-circle-up"></i>
  </span>

  <span className="wpp" >
    <a href="https://api.whatsapp.com/send?phone=59898721454&text=Hola%20quisiera%20hacerte%20una%20consulta."
      target="_blank"><i className="fab fa-whatsapp"></i>
    </a>
  </span>
  </Fragment>
  )
}

export default Iconos