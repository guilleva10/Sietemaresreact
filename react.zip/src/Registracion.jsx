import React, { useState } from "react";
import { Fragment } from 'react';
import "./Registracion.css";
import Axios from "axios";




function Registracion() {
    const url = "http://localhost:4001/registracion"
    const [data, setData] = useState({
        nombre: "",
        apellido: "",
        email: "",
        celular: "",
        contraseña: ""
    })

    async function submit(e) {
        e.preventDefault();
        const res = await Axios.post(url, {
            nombre: data.nombre,
            apellido: data.apellido,
            email: data.email,
            celular: data.celular,
            contraseña: data.contraseña,
        })
        
    }

    function handle(e) {
        const newdata = { ...data }
        newdata[e.target.id] = e.target.value
        setData(newdata)
        
    }

    return (
        <Fragment>

        

        <form onSubmit={submit}>
    
            <div className="registracion13">
    
                <div className="infopersonal13">
                    <h2>Crea una cuenta!</h2>
                </div>
    
           
                
               
                <div className="mb-3">
                        <input type="text" id="nombre" name="nombre"  title="Nombre" placeholder="Nombre" value={data.nombre} onChange={(e) => handle(e) }
                            className="form-control" data-validate="{required:true}" autocomplete="on"
                            aria-required="true"/></div>
                
                <div className="mb-3">
                    
                    <input type="text" id="apellido" name="apellido"  title="Apellido" placeholder="Apellido" value={data.apellido} onChange={(e) => handle(e) }
                        className="form-control" data-validate="{required:true}" autocomplete="on"
                        aria-required="true"/>
                </div>
    
                <div className="mb-3">
                   
                    <input type="email" id="email" name="email"  title="Email" placeholder="E-mail" className="form-control" value={data.email} onChange={(e) => handle(e) }
                        data-validate="{required:true}" autocomplete="on" aria-required="true"/>
                </div>
    
                <div className="mb-3">
                   
                    <input type="tel" id="celular" name="celular"  title="Celular" placeholder="Celular" className="form-control" value={data.celular} onChange={(e) => handle(e) }
                         data-validate="{required:true}" autocomplete="off"/>
                </div>
                <div className="mb-3">
                    
                    <input type="password" id="contraseña" name="contraseña"  title="Contraseña" placeholder="Contraseña" value={data.contraseña} onChange={(e) => handle(e) }
                        className="form-control" data-validate="{required:true}" autocomplete="off"
                        aria-required="true"/>
                </div>
                
    
                <div className="mb-3">
                  
                    <button type="submit" className="btn btn-secondary">Registrarse</button>
    
                    <div className="redireccion2">
                        
                        <label> <a className="red13" href="/login">Ya tienes cuenta? Inicia sesión!</a> </label>
                    </div>
        
                </div>
            </div>
    
    
        </form>
        </Fragment>
    )
    }   
export default Registracion;