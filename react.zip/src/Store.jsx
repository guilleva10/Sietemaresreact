import React, { Fragment } from "react";
import Item from "./Productoimagen.jsx";
import { Productos } from "./Productos.js";
import { Talles } from "./Talles.js";
import "./Articulo.css";

const Store = () => {
  return (
    <Fragment>
      <div className="generalproductos">
        <div className="asideproductos">
          <h1 className="catalogo"> CATÁLOGO</h1>

          <div className="categorias"></div>

          <h2 className="winter"> Winter</h2>
          <br />
          <a href="">
            <h3>Buzos</h3>
          </a>
          <br />
          <a href="">
            <h3>Chaquetas</h3>
          </a>
          <br />
          <a href="">
            <h3>Chalecos</h3>
          </a>
          <br />
          <a href="">
            <h3>Pantalones</h3>
          </a>
          <br />
          <a href="">
            <h3>Sacos</h3>
          </a>
          <br />
          <a href="">
            <h3>Bluzas</h3>
          </a>
          <br />
          <h2 className="summer"> Summer</h2>
          <br />
          <a href="">
            <h3>Camisas</h3>
          </a>
          <br />
          <a href="">
            <h3>Shorts</h3>
          </a>
          <br />
          <a href="">
            <h3>Tops</h3>
          </a>
          <br />
          <a href="">
            <h3>Monos</h3>
          </a>
          <br />
          <a href="">
            <h3>Vestidos</h3>
          </a>
          <br />
          <a href="">
            <h3>Accesorios</h3>
          </a>

          <div className="precio">
            <h1 className="tituloprecio"> PRECIO</h1>
          </div>
          <div className="filtroprecio">
            <form action="" class="frm">
              <div class="cnt">
                <label class="lblPrecio">
                  <b>Desde</b>
                  <input
                    autocomplete="off"
                    placeholder="Desde"
                    type="number"
                    min="0"
                    name="min"
                    
                  />
                </label>
                <label class="lblPrecio">
                  <b>Hasta</b>
                  <input
                    autocomplete="off"
                    placeholder="Hasta"
                    type="number"
                    min="0"
                    name="max"
                    
                  />
                </label>
                <button class="btn btn-secondary" type="submit">
                  Filtrar
                </button>
              </div>
            </form>
          </div>
        </div>

        <div className="productosarticulo">
          {Productos.map((articulo) => {
            return (
              <Item
                id={articulo.id}
                nombre={articulo.nombre}
                precio={articulo.precio}
                categoria={articulo.categoria}
                temporada={articulo.temporada}
                imagen={articulo.imagen}
              />
            );
          })}
        </div>
      </div>
    </Fragment>
  );
};

export default Store;
