import React from "react";
import './Carousel.css';
import { Fragment } from 'react';

const Carousel = ({imagen12,imagen22,imagen32}) => {

    return (
      <Fragment>
    <div id="carouselExampleControls2" className="carousel slide" data-bs-ride="carousel">
  <div className="carousel-inner">
    <div className="carousel-item active">
      <img src={imagen12} className="d-block " ></img>
    </div>
    <div className="carousel-item">
      <img src={imagen22} className="d-block"></img>
    </div>
    <div className="carousel-item">
      <img src={imagen32} classname="d-block" ></img>
    </div>
  </div>
  <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls2" data-bs-slide="prev">
    <span className="carousel-control-prev-icon" aria-hidden="true"></span>
    <span className="visually-hidden">Previous</span>
  </button>
  <button className="carousel-control-next" type="button" data-bs-target="#carouselExampleControls2" data-bs-slide="next">
    <span className="carousel-control-next-icon" aria-hidden="true"></span>
    <span className="visually-hidden">Next</span>
  </button>
</div>
</Fragment>
)
}

export default Carousel
