import React from "react";
import { Fragment } from 'react';
import "./Contacto.css";


const Contacto = () => { 

    return(

<Fragment>
    
    <div className="contacto">

<form  action='/contacto' method='POST'  class='frm frm01 lblLeft'  id='frmContacto'>
<span className="registracion14">
<span><input type='hidden' name='_frm' value='frmContacto'  /></span>
    <div class="mb-3">
        <div id="fldNombre" class="mb-3">
            <label class="lbl"><b>Nombre</b><input type='text'   name='txtNombre' class="v_required" required /></label>
        </div>
                    <div id="fldApellido" class="mb-3">
                <label class="lbl"><b>Apellido</b>
                <input type='text'   name='txtApellido' class="v_required" required  /></label>
            </div>               
                <div id="fldEmail" class="mb-3">
            <label class="lbl"><b>E-mail</b><input type='email'   name='txtEmail' class="v_required v_email" required /> </label>
        </div>                    
        <div id="fldMensaje" class="mb-3">
            <label class="lbl"><b>Mensaje</b><textarea  name='txtMensaje' class="v_required" required cols='24' rows='5' ></textarea></label>
        </div>
  
    </div>
    <div class="mb-3">
        <button type="submit" class="btn btn-secondary">Enviar</button>
        
    </div>

    </span>
</form>

<span>
<div id="secondary">
    <br />
    <br />
    <br />

        <div class="blk blkDir">
            <div class="cnt vcard">
                <strong class="org">Sietemares</strong>
                <address class="adr">
                    <span class="street-address">Jaime Zudañez 2815</span> <br/>
                    <span class="locality">Montevideo</span>, <span class="region">Montevideo</span><br/>
                    <span class="country-name">Uruguay</span>
                </address>
                <div class="contact">
                    <strong class="tel">+598 98 721 454</strong><br/>
                    <span class="mail"><a href="mailto:contacto@sietemares.uy">contacto@sietemares.uy</a></span>
                </div>
                <div class="note">Lunes a Viernes de  09:00 a 18:00 hs</div>
                <span className="instagram1">
          <a href="https://www.instagram.com/sietemares.uy/" target="_blank"><i className="fab fa-instagram"></i></a>
        </span>
            </div>
        </div>
    </div>
</span>
</div>
</Fragment>
)


}
export default Contacto