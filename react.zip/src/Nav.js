import React, { useState } from "react";

import './Nav.css';




const Nav = () => {

  
    const [open, setOpen] = useState(false);

    const toggle = () => {setOpen(!open)};
  
        

    return (
      <nav>
        <div className="nav">
        <div className={open ? 'hamburger is-active' : 'hamburger'}  onClick={toggle}>
          <div className="_layer -top"></div>
          <div className="_layer -mid"></div>
          <div className="_layer -bottom"></div>
        </div>
        <div className={open ? 'menuppal is_active' : 'menuppal'}> 
          <ul >
            <li></li>
            <li><a href="/aboutus">ABOUT US</a></li>
            <li><a href="/contacto">CONTACT US</a></li>
            <li><a href="/store">STORE</a></li>
            
            
            <li><a href="/login"> SIGN UP <i className="fas fa-user-alt"></i></a></li>
          </ul>
        </div>
    
        <span id="nada">
    
        </span>
    
        <span>
    
        <a className="linkhome" href="/"><h1 className="titulo">SIETEMARES</h1></a>
        </span>
    
        <span className="buscar">
          
        </span>
    
        <span> </span>
    
        <ul class="orderlist">
            <li><a href="/aboutus">ABOUT US</a></li>
            <li><a href="/contacto">CONTACT US</a></li>
            <li><a href="/store">STORE</a></li>
            
        </ul>
    
        <span class="iconos">
          
    
          <a href="/registracion"> <i className="large material-icons" >account_circle</i></a>
    
          <a href="/cart"> <i className="large material-icons">shopping_cart</i></a>
        </span>
      </div>

      </nav>
    )
  };
  
  export default Nav;