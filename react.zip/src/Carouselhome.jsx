import React from "react";
import './Carouselhome.css'
import { Fragment } from 'react';

const Carouselhome = ({imagen1home,imagen2home,imagen3home}) => {

    return(

<Fragment>
<div id="carouselExampleCaptions1" className="carousel slide" data-bs-ride="carousel">
  <div className="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleCaptions1" data-bs-slide-to="0" className="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions1" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions1" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div className="carousel-inner">
    <div className="carousel-item active">
      <img src={imagen1home} className="d-block w-100"  alt="..."></img>
      <div className="carousel-caption d-none d-md-block">
        <h5>SIETEMARES</h5>
        <p>Grow your mind.</p>
      </div>
    </div>
    <div className="carousel-item">
      <img src={imagen2home} className="d-block w-100"  alt="..."></img>
      <div className="carousel-caption d-none d-md-block">
        <h5>SIETEMARES</h5>
        <p>Be the energy you want to attract.</p>
      </div>
    </div>
    <div className="carousel-item">
      <img src={imagen3home} className="d-block w-100"  alt="..."></img>
      <div className="carousel-caption d-none d-md-block">
        <h5>SIETEMARES</h5>
        <p>Be positive</p>
      </div>
    </div>
  </div>
  <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions1" data-bs-slide="prev">
    <span className="carousel-control-prev-icon" aria-hidden="true"></span>
    <span className="visually-hidden">Previous</span>
  </button>
  <button className="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions1" data-bs-slide="next">
    <span className="carousel-control-next-icon" aria-hidden="true"></span>
    <span className="visually-hidden">Next</span>
  </button>
</div>
</Fragment>
    )
}

export default Carouselhome