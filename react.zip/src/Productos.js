

export const Productos = [
    {
      id: 1,
      nombre: "Lulu",
      precio: 1150,
      categoria: "Buzos",
      temporada: "Invierno",
      imagen: "/assets/Imagen3.jpeg"
      
    },
    {
        id: 2,
        nombre: "Mare",
        precio: 1300,
        categoria: "Chaquetas",
        temporada: "Invierno",
        imagen: "/assets/Imagen4.jpeg"       
      },
      {
        id: 3,
        nombre: "Akira",
        precio: 1150,
        categoria: "Chalecos",
        temporada: "Invierno",
        imagen: "/assets/Imagen5.jpeg"
        
      },
      {
        id: 4,
        nombre: "Bombay",
        precio: 2000,
        categoria: "Chaquetas",
        temporada: "Invierno",
        imagen: "/assets/Imagen6.jpeg"
      },
      {
        id: 5,
        nombre: "Lulu2",
        precio: 1200,
        categoria: "Buzos",
        temporada: "Invierno",
        imagen: "/assets/Imagen3.jpeg"
        
      },
      {
        id: 6,
        nombre: "Bono",
        precio: 1150,
        categoria: "Pantalones",
        temporada: "Invierno",
        imagen: "/assets/Imagen8.jpeg"
        
      },
      {
        id: 7,
        nombre: "Teresa",
        precio: 1150,
        categoria: "Shorts",
        temporada: "Verano",
        imagen: "/assets/short.jpeg"
        
      },
      {
        id: 8,
        nombre: "Coco",
        precio: 1300,
        categoria: "Mono",
        temporada: "Verano",
        imagen: "/assets/conjunto2.jpeg"
        
      },
      {
        id: 9,
        nombre: "Cristina",
        precio: 1300,
        categoria: "Camisas",
        temporada: "Verano",
        imagen: "/assets/camisarosada.jpeg"
      },
      {
        id: 10,
        nombre: "Collar",
        precio: 1300,
        categoria: "Accesorios",
        temporada: "Invierno",
        imagen: "/assets/mochila.jpeg"
      },
  ];
  