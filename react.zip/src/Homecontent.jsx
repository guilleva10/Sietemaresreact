import React, { Fragment } from 'react';
import Carousel from './Carousel.jsx';
import Carouselhome from './Carouselhome.jsx';
import Hometitulo from './Hometitulo.jsx';
 import './Homecontent.css';

 

const Homecontent = () => {

return (
  
  <Fragment>
   
    
    <Carouselhome
    imagen1home="\assets\conjuntoamarillo2.jpeg"
    imagen2home="\assets\conjuntorosado4.jpeg"
    imagen3home="\assets\Imagen3.jpeg">        
    </Carouselhome>

 <Hometitulo nombre="summer"></Hometitulo>
 <div className="carouseldiv">
   <Carousel
    imagen12="\assets\camisashort3.jpeg"
    imagen22="\assets\Imagen5.jpeg"
    imagen32="\assets\Imagen3.jpeg">      
    </Carousel>
    <Carousel
    imagen12="\assets\fondoamarillo.jpeg"
    imagen22="\assets\Imagen4.jpeg"
    imagen32="\assets\conjunto3.jpeg">      
    </Carousel>
    </div>
  <Hometitulo nombre="winter"></Hometitulo>
  <div className="carouseldiv">
  <Carousel
    imagen12="\assets\fondoamarillo.jpeg"
    imagen22="\assets\camisashort.jpeg"
    imagen32="\assets\conjunto3.jpeg">      
    </Carousel>
    <Carousel
    imagen12="\assets\conjuntonaranja.jpeg"
    imagen22="\assets\conjuntorosado3.jpeg"
    imagen32="\assets\conjunto3.jpeg">      
    </Carousel></div>

  <Hometitulo nombre="new arrivals"></Hometitulo>
    <div className="carouseldiv">
    <Carousel
    imagen12="\assets\fondoamarillo.jpeg"
    imagen22="\assets\Imagen4.jpeg"
    imagen32="\assets\Imagen3.jpeg">      
    </Carousel>
    <Carousel
    imagen12="\assets\fondoamarillo.jpeg"
    imagen22="\assets\Imagen4.jpeg"
    imagen32="\assets\Imagen3.jpeg">      
    </Carousel>
    </div>

    </Fragment>
    
)




}
export default Homecontent