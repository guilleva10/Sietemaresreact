import React from "react";
import './Hometitulo.css';
import { Fragment } from 'react';

const Hometitulo = ({nombre}) => {

    return (
        <Fragment>
        <div className="titulohomecontent">
        <span></span>
        <div className="contenedortitulohome">
        <h1 className="titulo2"> {nombre}</h1>
        </div>
        <span></span>
         </div>
         </Fragment>
    )


    }

    export default Hometitulo